from groq import Groq
import os
from dotenv import load_dotenv
load_dotenv()

client = Groq(api_key=os.getenv("GROQ_API_KEY"))

# General purpose function
def _generate_from_groq(messages: str, model="llama3-8b-8192", temperature=0.5, max_tokens=1024) -> str:
    response = client.chat.completions.create(
        messages=messages,
        model=model,
        temperature=temperature,
        max_completion_tokens=max_tokens,
        top_p=1,
        stream=False,
    )
    return response.choices[0].message.content.strip()

# 1. Generate a startup plan
def generate_plan_groq(idea: str) -> str:
    messages = [
        {"role": "system", "content": "You are a startup coach helping founders plan launches."},
        {"role": "user", "content": f"Generate a comprehensive startup launch plan for this idea: {idea}"}
    ]
    return _generate_from_groq(messages)

# 2. Generate an email
def generate_email_groq(context: str) -> str:
    messages = [
        {"role": "system", "content": "You are an expert email copywriter."},
        {"role": "user", "content": f"Write a professional email based on this context: {context}."}
    ]
    return _generate_from_groq(messages)

# 3. Generate a task summary
def generate_summary_groq(tasks: str) -> str:
    task_list = ", ".join(tasks)
    messages = [
        {"role": "system", "content": "You are an assistant that summarizes tasks concisely."},
        {"role": "user", "content": f"Summarize the following tasks into a concise report: {task_list}"}
    ]
    return _generate_from_groq(messages)
