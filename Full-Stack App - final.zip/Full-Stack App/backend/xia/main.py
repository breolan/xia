from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List
from database import get_db_connection, init_db
from groq_client import generate_email_groq,generate_plan_groq,generate_summary_groq


app = FastAPI()

# Initialize the database
init_db()

# Pydantic models
class PlanRequest(BaseModel):
    idea: str

class EmailRequest(BaseModel):
    context: str
    details: str

class SummaryRequest(BaseModel):
    tasks: List[str]

class TaskRequest(BaseModel):
    title: str
    status: str  # 'pending' or 'completed'

class TaskStatusUpdate(BaseModel):
    status: str  # 'pending' or 'completed'

# Endpoints
@app.post("/generate-plan")
def generate_plan(request: PlanRequest):
    prompt = f"Generate a startup launch plan for: {request.idea}"
    try:
        content =  generate_plan_groq(prompt)
        return {"plan": content}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/generate-email")
def generate_email(request: EmailRequest):
    prompt = f"Write an email for the following context: {request.context}. Details: {request.details}"
    try:
        content = generate_email_groq(prompt)
        return {"email": content}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/generate-summary")
def generate_summary(request: SummaryRequest):
    task_list = ", ".join(request.tasks)
    prompt = f"Summarize the following tasks: {task_list}"
    try:
        content = generate_summary_groq(prompt)
        return {"summary": content}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/add-task")
def add_task(task: TaskRequest):
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute(
            "INSERT INTO tasks (title, status) VALUES (?, ?)",
            (task.title, task.status)
        )
        conn.commit()
        return {"message": "Task added successfully."}
    except Exception as e:
        conn.rollback()
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        conn.close()

@app.put("/update-task-status/{task_id}")
def update_task_status(task_id: int, status_update: TaskStatusUpdate):
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute(
            "UPDATE tasks SET status = ? WHERE id = ?",
            (status_update.status, task_id)
        )
        if cursor.rowcount == 0:
            raise HTTPException(status_code=404, detail="Task not found.")
        conn.commit()
        return {"message": "Task status updated successfully."}
    except Exception as e:
        conn.rollback()
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        conn.close()

@app.get("/task-history")
def task_history():
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT id, title, status, created_at FROM tasks ORDER BY created_at DESC")
        tasks = cursor.fetchall()
        return {"tasks": [dict(task) for task in tasks]}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        conn.close()
